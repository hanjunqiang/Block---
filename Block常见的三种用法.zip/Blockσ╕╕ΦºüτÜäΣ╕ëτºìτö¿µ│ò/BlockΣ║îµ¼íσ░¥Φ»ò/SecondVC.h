//
//  SecondVC.h
//  Block二次尝试
//
//  Created by 韩军强 on 2016/12/29.
//  Copyright © 2016年 ios. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^SecondBlock)(NSString *string);

@interface SecondVC : UIViewController

//方式1
@property (nonatomic, copy) SecondBlock block2;

//方式3
//可以用dispatch_block_t快速声明无参数、无返回值的block
@property (nonatomic, copy) dispatch_block_t testBlock;

//方式2
-(void)clickBlockAction:(SecondBlock)clickBlock;

@end
