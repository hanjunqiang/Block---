
//
//  SecondVC.m
//  Block二次尝试
//
//  Created by 韩军强 on 2016/12/29.
//  Copyright © 2016年 ios. All rights reserved.
//

#import "SecondVC.h"

@interface SecondVC ()

@end

@implementation SecondVC

- (void)viewDidLoad {
    [super viewDidLoad];



}
- (IBAction)firstBtn:(id)sender {
    
    //方式1
//    self.block2(@"mrhan");
    
    //方式2
    //判断clickBlockAction方法是否赋值了self.block2
    if (self.block2) {
        self.block2(@"mrhan");
    }
    
    //方式3
//    self.testBlock();
}

//上个界面实现block的时候会调用这里
-(void)clickBlockAction:(SecondBlock)clickBlock
{
    self.block2 = clickBlock;
}

- (IBAction)secondBtn:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
