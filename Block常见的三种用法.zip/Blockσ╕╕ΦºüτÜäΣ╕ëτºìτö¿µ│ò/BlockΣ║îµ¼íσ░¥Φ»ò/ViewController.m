//
//  ViewController.m
//  Block二次尝试
//
//  Created by 韩军强 on 2016/12/29.
//  Copyright © 2016年 ios. All rights reserved.
//

#import "ViewController.h"
#import "SecondVC.h"

@interface ViewController ()
@property (nonatomic, strong) SecondVC *vc;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SecondVC *vc = [SecondVC new];
    self.vc = vc;
    
    /*
        1,不论方式1直接实现blcok2，还是方式2通过方法来实现block2，
            其实方式1和方式2是同一个block2.
        2,如下如果是方式1和方式2都实现了，那么谁最后实现，就会调用谁。
     */
    
    //1,直接实现block2
//    vc.block2 = ^(NSString *string)
//    {
//        NSLog(@"string-%@",string);
//    };
    
    //2,这里会调用SecondVC中的clickBlockAction：方法，
    //并且给self.block2进行赋值。
    [vc clickBlockAction:^(NSString *string2) {
        NSLog(@"string2-%@",string2);
    }];
    
    //3，使用系统声明无参数、无返回值的block,这里是对应的回调实现方法
//    vc.testBlock = ^()
//    {
//        NSLog(@"有意思");
//    };

}
- (IBAction)huidiaoBtn:(id)sender {
    
}

- (IBAction)tiaozhuanBtn:(id)sender {
    [self presentViewController:self.vc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
